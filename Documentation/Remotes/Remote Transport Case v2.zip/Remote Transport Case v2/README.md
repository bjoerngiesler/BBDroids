# Remote Transport Case V2

This is a transport case that fits James Pearson Ballan's cases ("Remote Case v0.27")for the Monaco Control System, plus small tools, cable, etc.

## Printed Parts and Materials

No special requirements for anything except of course the parts labeled "TPU".

Please note that the inserts can be a tight fit depending on material and printer calibration. For my last print I had to scale up the outer case parts by 0.5% to make it work.

I like to print the outer case parts (Case Bottom, Case Lid + Logo) in PETG because it is tough, resilient stuff. If your printer supports multi-material, the case lid + logo file can be printed in different colors for a nice Aurebesh label. Or you can just use your slicer software to fuse the different parts of that file together and print in a single color.

I've experimented with printing the inserts in LW-PLA because I still had some around. It's softer than regular PLA so the thinking was that it wouldn't scratch the remote cases. But not a big deal.

## Other Hardware

You need 6 M3x20mm socket head screws. Two of these form the hinge between bottom and lid, two form the hinges for the TPU latches, and the last two are the bars that the TPU latches hold on to when the case is closed. These are self-tapping and screw in from the sides.

For the magnet lid, you need 4 neodymium disk magnets of 10mm diameter and 2mm thickness. These should press in (and probably need quite some coercion), but if that's not enough, glue them in with some superglue or better epoxy. 

**NOTE** If you use superglue anywhere on the case, make sure you keep the case open while the glue dries, otherwise the fumes will cause discolorations in the case! 

## Assembly

Should be straightforward:
* Assemble top and bottom case shell with two M3x20mm screws
* Press the magnets into the magnet lid and top insert
* Push the top and bottom insert into the case - can glue these or just push fit
* Glue the rectangular TPU inserts into the top and bottom recesses
* Add the round TPU inserts for the joysticks - can glue these or just push fit
* Add the TPU latches to the top shell with two M3x20mm screws and add the last two screws to the bottom shell
* Done! 
